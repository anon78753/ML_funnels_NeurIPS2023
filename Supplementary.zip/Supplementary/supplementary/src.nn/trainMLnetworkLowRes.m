clear 

for iruns=1:9
% rng(3988) % initialize random number generator to enforce repeatability of train/test/val splits
rng('shuffle'); % initialize random number generator for random train/test/val splits
s=rng; 

% PG network setup, loads multiple comsol datafiles as training sets
%construction of file lists containing data for training sets
cmlPref='../cmlData/cmlDataHRZ.lowRes.wp='; cmlSuf='.mat';
cmlMed={'6','7','8.5','10','11'}; 

% setting up labeled and unlabeled training sets; lists must match 
% training files
lblFrac=[0.5, 0, 0.1, 0, 0.5]; 
ulFrac=[0, 0.5, 0.4, 0.5, 0]; 
% ulFrac=[0, 0, 0.4, 0, 0]; 
% ulFrac=[0, 0, 0., 0, 0]; 

lblTrain=cell(length(cmlMed),1); 
ulTrain=cell(length(cmlMed),1);
test=cell(length(cmlMed),1);

for ifl=1:length(cmlMed)
    cmlData=load([cmlPref,cmlMed{ifl},cmlSuf]); 
    numDat = length(cmlData.lamArr);
    cmlSz=[size(cmlData.rDns,1),size(cmlData.rDns,2) 3]; 
    if ~exist('trainEps','var')
        totTrain=0; 
        for it=1:length(cmlMed)
            [tmp,lbl,ul] = dividerand(numDat,1-lblFrac(it)-ulFrac(it),lblFrac(it),ulFrac(it)); 
            lblTrain{it}=lbl; 
            ulTrain{it}=ul; 
            test{it}=tmp; 
            totTrain=totTrain+length(lbl)+length(ul); 
        end 
        trainEps=cell(totTrain,1); 
        trainH=cell(totTrain,1); 
        iTrain=0;
    end 
 

    for it=1:length(lbl)
        iTrain=iTrain+1; 

        trainEps{iTrain}=zeros( cmlSz(1),cmlSz(2),3); 
        trainEps{iTrain}(:,:,1)=real(cmlData.epsDns(:,:,lbl(it)));
        trainEps{iTrain}(:,:,2)=imag((cmlData.epsDns(:,:,lbl(it)))); 
        trainEps{iTrain}(:,:,3)=cmlData.lamArr(lbl(it)); 
    
        %field data
        trainH{iTrain}=zeros( cmlSz(1),cmlSz(2),11); 
        trainH{iTrain}(:,:,1)=real((cmlData.HphiDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,2)=imag((cmlData.HphiDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,3)=real((cmlData.EphiDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,4)=imag((cmlData.EphiDns(:,:,lbl(it)))); 
        %PG data
        trainH{iTrain}(:,:,5)=real(cmlData.epsDns(:,:,lbl(it)));
        trainH{iTrain}(:,:,6)=imag((cmlData.epsDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,7)=cmlData.lamArr(lbl(it)); 
        %extra field data
        trainH{iTrain}(:,:,8)=real((cmlData.HrDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,9)=imag((cmlData.HrDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,10)=real((cmlData.HzDns(:,:,lbl(it)))); 
        trainH{iTrain}(:,:,11)=imag((cmlData.HzDns(:,:,lbl(it)))); 
    end 

    for it=1:length(ul)
        iTrain=iTrain+1; 

        trainEps{iTrain}=zeros( cmlSz(1),cmlSz(2),3); 
        trainEps{iTrain}(:,:,1)=real(cmlData.epsDns(:,:,ul(it)));
        trainEps{iTrain}(:,:,2)=imag((cmlData.epsDns(:,:,ul(it)))); 
        trainEps{iTrain}(:,:,3)=cmlData.lamArr(ul(it)); 
    
        %field data
        trainH{iTrain}=zeros( cmlSz(1),cmlSz(2),11); 
        %PG data
        trainH{iTrain}(:,:,5)=real(cmlData.epsDns(:,:,ul(it)));
        trainH{iTrain}(:,:,6)=imag((cmlData.epsDns(:,:,ul(it)))); 
        trainH{iTrain}(:,:,7)=cmlData.lamArr(ul(it)); 
        trainH{iTrain}(2,1,7)=-1; % mark UL data
    end 

end     

%% build the network

layers = [
    sequenceInputLayer(cmlSz)
    sequenceFoldingLayer("Name","fold")
    split3Layer("split1")
    convolution2dLayer(11,3, 'Padding',[5 5 0 10])
    tanhLayer
    convolution2dLayer([5 4],24,'Stride',[3 2], 'Padding',[1 1 0 2])
    tanhLayer
    convolution2dLayer([5 3],24,'Padding',[1 3 0 2])
    tanhLayer
    mergeLamLayer("merge1")
    convolution2dLayer([5 3],24,'Padding',[1 3 0 2])
    tanhLayer
    transposedConv2dLayer([3 2],24,'Stride',[3 2],'Cropping',[0 0 0 0])
    tanhLayer
    convolution2dLayer([5 3],24,'Padding',[1 3 0 2])
    tanhLayer
    convolution2dLayer(11,12, 'Padding',[5 5 0 10])

    % trailing layers... 

    merge3Layer("merge2")

    tanhLayer
    convolution2dLayer(10,12,'Padding',[4 5 0 9])
    tanhLayer
    convolution2dLayer(5,8,'Padding',[2 2 0 4])
    tanhLayer
    convolution2dLayer(5,4,'Padding',[2 2 0 4])
    tanhLayer
    groupedConvolution2dLayer(5,1,"channel-wise",'Padding',[2 2 0 4])
    tanhLayer
    groupedConvolution2dLayer([10 3],1,"channel-wise",'Padding',[4 5 0 2])
    merge3Layer("merge3")

    % added layer for generation of z/r fields
    genRZLayer("RZ",cmlData.rDns,cmlData.zDns)

    sequenceUnfoldingLayer("Name", "unfold")
    PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, 500, 250, 1, 0.25, 1)]; % PG loss
    % PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, 500, 250, 1, 0, 1)]; %no PG, all MSE
    % PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, 500, 250, 1, 0, 0)]; %no PG, phi MSE
layers = layerGraph(layers);
layers = connectLayers(layers,'split1/copy1','merge1/copy');
layers = connectLayers(layers,'split1/copy2','merge2/copy');
layers = connectLayers(layers,'split1/copy3','merge3/copy');
layers = connectLayers(layers,'fold/miniBatchSize','unfold/miniBatchSize');

%
% Plot the ANN
figure(2)
set(gca,'FontSize',18)
plot(layers);


options = trainingOptions('adam', ...
    'InitialLearnRate',0.002, ...
    'LearnRateSchedule','piecewise',...
    'LearnRateDropPeriod',1000, ...
    'LearnRateDropFactor',0.75,...
    'MiniBatchSize',40,...
    'Shuffle','every-epoch', ...
    'MaxEpochs',100, ...
    'Verbose',false, ...
    'Plots','training-progress', ...
    'ExecutionEnvironment','gpu');

[net, info] = trainNetwork(trainEps,trainH,layers,options);
save(['../nets/lowResNet.PGallUL.6.11.TEST.seed=',num2str(s.Seed),'.mat'],...
    "net","cmlSz","test","lblTrain","ulTrain",...
    "cmlPref","cmlMed","cmlSuf","info")

clear trainEps
end