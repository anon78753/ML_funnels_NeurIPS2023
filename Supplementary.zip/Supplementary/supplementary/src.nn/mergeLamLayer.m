classdef mergeLamLayer < nnet.layer.Layer

%     properties (Learnable)
%         scale
%     end 
    methods
        function layer = mergeLamLayer(name)
            % (Optional) Create a myLayer.
            % This function must have the same name as the class.

            % Layer constructor function goes here.
            layer.Name = name;
            layer.Description = 'test layer';
            layer.NumInputs =2 ; 
            layer.InputNames={'networkIn','copy'};
            layer.OutputNames = {'data'};
%             layer.scale=1; 

        end

        % splits intput into two, in order to pass config array into
        % PG-layer
        function [Z1] = predict(layer, X1,X2)
%             disp([layer.scale])
            sz=size(X1);sz(3)=sz(3)+1;
            Z1=zeros(sz,'like',X1); 
            Z1(:,:,1:end-1,:)=X1(:,:,:,:);
            lamArr=X2(1,1,3,:).*ones(sz(1),sz(2)); 
            Z1(:,:,end,:)=lamArr(:,:,1,:); 

%             Z1 = zeros(size(X1),'like',X1)+X1; 
        end

%         function dLdX = backward(~,X1, Z1, dLdZ1, ~)
%             dLdX=0*X1; 
%             dLdX(:)=dLdZ1(:); 
%         end 
        
    end
end