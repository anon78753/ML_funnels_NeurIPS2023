clear 

figure(11)
clf
hold on 

figure(13)
clf 
hold on 

sufLst={'MSEphi','MSErz','PGwUL'}; 

for isf=1:length(sufLst)
clear MSEPhiArr

modelLst=dir(['../nets/lowResNet.',sufLst{isf},'.6.11*']); %get list of files in this config run


% calculate the total number of datasets with labeled and UL data
lblTrainTot=0; ulTrainTot=0; testTot=0; 
for im=1:length(modelLst)
    model=load([modelLst(im).folder,'/',modelLst(im).name],"lblTrain","ulTrain","test"); 
    model.cmlPref='../cmlData/cmlDataHRZ.lowRes.wp=';
    % cmlData=load([cmlPref,cmlMed{ifl},cmlSuf]);
    for ifl=1:length(model.lblTrain)
        if length(model.lblTrain{ifl})>10
            lblTrainTot=lblTrainTot+1; 
        elseif ~isempty(model.ulTrain{ifl})
            ulTrainTot=ulTrainTot+1; 
        else 
            testTot=testTot+1; 
        end 
    end 
end 

ilCur=0; iulCur=0; itstCur=0; 
for im=1:length(modelLst) %iterate over models
    model=load([modelLst(im).folder,'/',modelLst(im).name]); 
    model.cmlPref='../cmlData/cmlDataHRZ.lowRes.wp=';
    for ifl=1:length(model.lblTrain) %iterate over comsol files
        cmlData=load([model.cmlPref,model.cmlMed{ifl},model.cmlSuf]);

        lamArr=cmlData.lamArr; 
        if ~exist("MSEPhiArr","var")
            MSEPhiArr=cell(3,1); 

            MSEPhiArr{1}=zeros(lblTrainTot,length(lamArr));
            MSEPhiArr{2}=zeros(ulTrainTot,length(lamArr));
            MSEPhiArr{3}=zeros(testTot,length(lamArr));

            MSEAllArr=MSEPhiArr; 
            PGLossArr=MSEPhiArr;
        end 
        if length(model.lblTrain{ifl})>10
            ilCur=ilCur+1;
            iCur=ilCur; typeCur=1; 
        elseif ~isempty(model.ulTrain{ifl})
            iulCur=iulCur+1;
            iCur=iulCur; typeCur=2; 
        else 
            itstCur=itstCur+1;
            iCur=itstCur; typeCur=3; 
        end 

        PGlr=genRZLayer("RZ",cmlData.rDns,cmlData.zDns); 
        MSEPhiLr=PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, -100000, 500, 1, 0,0);
        MSEAllLr=PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, -100000, 500, 1, 0,1);
        PGLossLr=PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, -100000, 500, 0, 1,1);

        for il=1:length(lamArr)
        
            % ML interpretation
            X=zeros([size(cmlData.rDns,1),size(cmlData.rDns,2) 3]); 
            X(:,:,1)=real(cmlData.epsDns(:,:,il)); 
            X(:,:,2)=imag(cmlData.epsDns(:,:,il)); 
            X(:,:,3)= cmlData.lamArr(il);
        
            Y=predict(model.net,X);
        
            T=zeros([size(cmlData.rDns,1),size(cmlData.rDns,2) 11]);
        
            T(:,:,1)=real(cmlData.HphiDns(:,:,il)); T(:,:,2)=imag(cmlData.HphiDns(:,:,il)); 
            T(:,:,3)=real(cmlData.EphiDns(:,:,il)); T(:,:,4)=imag(cmlData.EphiDns(:,:,il)); 
            T(:,:,5)=real(cmlData.epsDns(:,:,il)); T(:,:,6)=imag(cmlData.epsDns(:,:,il)); 
            T(:,:,7)=lamArr(il); 
            T(:,:,8)=real(cmlData.HrDns(:,:,il)); T(:,:,9)=imag(cmlData.HrDns(:,:,il)); 
            T(:,:,10)=real(cmlData.HzDns(:,:,il)); T(:,:,11)=imag(cmlData.HzDns(:,:,il)); 
        
            Y=reshape(Y,[size(Y),1]); 
            T=reshape(T,[size(T),1]); 
        
            MSEPhiArr{typeCur}(iCur,il)=MSEPhiLr.forwardLoss(Y,T); 
            MSEAllArr{typeCur}(iCur,il)=MSEAllLr.forwardLoss(Y,T); 
            PGLossArr{typeCur}(iCur,il)=PGLossLr.forwardLoss(Y,T); 
        end 
    end 
end 

%% plotting

for iplt=[1,3]
figure(10+iplt)
hold on 

plot(lamArr,mean(MSEPhiArr{iplt}),'-', ...
    'LineWidth',2)

set(gca,'colorOrderIndex',get(gca,'ColorOrderIndex')-1)

plot(lamArr,mean(PGLossArr{iplt}),'--', ...
    'LineWidth',2,'HandleVisibility','off')
% set(gca,'yscale','log')
box on 
% legend('FEM','PGML','baseline ML', 'Location','West')
set(gca,'FontSize',18)
xlabel('wavelength, \mum')
% yticks([1e-1,1,1e1])
ylabel('<L>')
drawnow 
% ylim([0 0.5])
end 

end 

%% finalize plots
figure(11)
legend({'BBNN','FENN', 'PGNN'})
set(gca,'yscale','log')

figure(13)
legend({'BBNN','FENN', 'PGNN'})
set(gca,'yscale','log')
