classdef merge3Layer < nnet.layer.Layer

%     properties (Learnable)
%         scale
%     end 
    methods
        function layer = merge3Layer(name)
            % (Optional) Create a myLayer.
            % This function must have the same name as the class.

            % Layer constructor function goes here.
            layer.Name = name;
            layer.Description = 'test layer';
            layer.NumInputs =2 ; 
            layer.InputNames={'networkIn','copy'};
            layer.OutputNames = {'data'};
%             layer.scale=1; 

        end

        % splits intput into two, in order to pass config array into
        % PG-layer
        function [Z1] = predict(layer, X1,X2)
%             disp([layer.scale])
            sz=size(X1);sz(3)=sz(3)+3;
            Z1=zeros(sz,'like',X1); 
            Z1(:,:,1:end-3,:)=X1(:,:,:,:);
            Z1(:,:,(end-2:end),:)=X2(:,:,(1:3),:); 

%             Z1 = zeros(size(X1),'like',X1)+X1; 
        end

%         function dLdX = backward(~,X1, Z1, dLdZ1, ~)
%             dLdX=0*X1; 
%             dLdX(:)=dLdZ1(:); 
%         end 
        
    end
end