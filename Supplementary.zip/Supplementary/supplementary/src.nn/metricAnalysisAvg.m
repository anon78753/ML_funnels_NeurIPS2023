clear 


sufLst={'MSEphi','MSErz','PGwUL'}; 

LphiAvg=zeros(1,length(sufLst)); 
LphiStd=0*LphiAvg; 

LphAvg=zeros(1,length(sufLst)); 
LphStd=0*LphiAvg; 

for isf=1:length(sufLst)
clear MSEPhiArr

modelLst=dir(['../nets/lowResNet.',sufLst{isf},'.6.11*']); %get list of files in this config run


% calculate the total number of datasets with labeled and UL data
testTot=0; 
for im=1:1%length(modelLst)
    model=load([modelLst(im).folder,'/',modelLst(im).name],"lblTrain","ulTrain","test"); 
    model.cmlPref='../cmlData/cmlDataHRZ.lowRes.wp=';
    % cmlData=load([cmlPref,cmlMed{ifl},cmlSuf]);
    for ifl=1:length(model.lblTrain)
        % if length(model.lblTrain{ifl})>10
        %     lblTrainTot=lblTrainTot+1; 
        % elseif ~isempty(model.ulTrain{ifl})
        %     ulTrainTot=ulTrainTot+1; 
        % else 
        testTot=testTot+length(model.test{ifl}); 
        % end 
    end 
end 

% ilCur=0; iulCur=0; 
Lphi=zeros(1,testTot);
Lph=zeros(1,testTot);

itstCur=0; 
for im=1:length(modelLst) %iterate over models
    model=load([modelLst(im).folder,'/',modelLst(im).name]); 
    model.cmlPref='../cmlData/cmlDataHRZ.lowRes.wp=';
    for ifl=1:length(model.lblTrain) %iterate over comsol files
        cmlData=load([model.cmlPref,model.cmlMed{ifl},model.cmlSuf]);

        lamArr=cmlData.lamArr(model.test{ifl}); 
        % if ~exist("MSEPhiArr","var")
        %     MSEPhiArr=cell(3,1); 
        % 
        %     MSEPhiArr{1}=zeros(lblTrainTot,length(lamArr));
        %     MSEPhiArr{2}=zeros(ulTrainTot,length(lamArr));
        %     MSEPhiArr{3}=zeros(testTot,length(lamArr));
        % 
        %     MSEAllArr=MSEPhiArr; 
        %     PGLossArr=MSEPhiArr;
        % end 
        % if length(model.lblTrain{ifl})>10
        %     ilCur=ilCur+1;
        %     iCur=ilCur; typeCur=1; 
        % elseif ~isempty(model.ulTrain{ifl})
        %     iulCur=iulCur+1;
        %     iCur=iulCur; typeCur=2; 
        % else 
        %     itstCur=itstCur+1;
        %     iCur=itstCur; typeCur=3; 
        % end 

        PGlr=genRZLayer("RZ",cmlData.rDns,cmlData.zDns); 
        MSEPhiLr=PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, -100000, 500, 1, 0,0);
        MSEAllLr=PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, -100000, 500, 1, 0,1);
        PGLossLr=PGregressionRZregLayer('regression',cmlData.rDns,cmlData.zDns, -100000, 500, 0, 1,1);

        for il=1:length(lamArr)
            itstCur=itstCur+1; 
        
            % ML interpretation
            X=zeros([size(cmlData.rDns,1),size(cmlData.rDns,2) 3]); 
            X(:,:,1)=real(cmlData.epsDns(:,:,il)); 
            X(:,:,2)=imag(cmlData.epsDns(:,:,il)); 
            X(:,:,3)= cmlData.lamArr(il);
        
            Y=predict(model.net,X);
        
            T=zeros([size(cmlData.rDns,1),size(cmlData.rDns,2) 11]);
        
            T(:,:,1)=real(cmlData.HphiDns(:,:,il)); T(:,:,2)=imag(cmlData.HphiDns(:,:,il)); 
            T(:,:,3)=real(cmlData.EphiDns(:,:,il)); T(:,:,4)=imag(cmlData.EphiDns(:,:,il)); 
            T(:,:,5)=real(cmlData.epsDns(:,:,il)); T(:,:,6)=imag(cmlData.epsDns(:,:,il)); 
            T(:,:,7)=lamArr(il); 
            T(:,:,8)=real(cmlData.HrDns(:,:,il)); T(:,:,9)=imag(cmlData.HrDns(:,:,il)); 
            T(:,:,10)=real(cmlData.HzDns(:,:,il)); T(:,:,11)=imag(cmlData.HzDns(:,:,il)); 
        
            Y=reshape(Y,[size(Y),1]); 
            T=reshape(T,[size(T),1]); 
        
            Lphi(itstCur)=MSEPhiLr.forwardLoss(Y,T); 
            % MSEAllArr{typeCur}(iCur,il)=MSEAllLr.forwardLoss(Y,T); 
            Lph(itstCur)=PGLossLr.forwardLoss(Y,T); 
        end 
    end 
end 

LphiAvg(isf)=mean(Lphi); LphiStd(isf)=std(Lphi);
LphAvg(isf)=mean(Lph); LphStd(isf)=std(Lph);


end 

%% plotting
x = categorical({'BBNN','FENN', 'PGNN'});
y = [LphiAvg(1:3).', LphAvg(1:3).'];
err = [LphiStd(1:3).', LphStd(1:3).'];

figure(10)
clf
b = bar(x,y, 'LineStyle','none', 'BarWidth',1);
hold on

for k = 1:numel(b)
    xtips = b(k).XEndPoints;
    ytips = b(k).YEndPoints;
    
    errorbar(xtips, ytips, err(:,k), '.k', 'LineWidth',2);
    
    % Draw line representing lower half of error bars when err > y
    idx = ytips - err(:,k).' < 0;
    negxtips = xtips(idx);
    negytips = ytips(idx);
    plot([negxtips; negxtips], [negytips; 1e-10*ones(size(negytips))], '-k', 'LineWidth', 2);
end

legend({'<L_\phi>:{low res}','<L_{ph}>:{low res}'})
set(gca, 'YScale', 'log')

set(gca,'FontSize',18)
ylim([3e-2 10])

ylabel('<L>')
box on 
set(gca, 'Layer', 'top')
hold off
