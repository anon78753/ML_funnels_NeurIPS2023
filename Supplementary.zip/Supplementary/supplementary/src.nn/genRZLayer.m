classdef genRZLayer < nnet.layer.Layer


    properties (Access = public)
        r2; %coordinate arrays
        z2; 
    end 
    
%     properties (Learnable)
%         scale
%     end 
    methods
        function layer = genRZLayer(name, r2, z2)
            % (Optional) Create a myLayer.
            % This function must have the same name as the class.

            % Layer constructor function goes here.
            layer.Name = name;
            layer.Description = 'compute H RZ components';
            layer.NumInputs =1 ; 
%             layer.InputNames={'networkIn','copy'};
%             layer.OutputNames = {'data'};

            %config parameters
            layer.r2=r2; 
            layer.z2=z2; 
        end

        % splits intput into two, in order to pass config array into
        % PG-layer
        function [Z1] = predict(layer, X1)
%             disp([layer.scale])
            X1=real(X1);  
            sz=size(X1);sz(3)=sz(3)+4;
            
            Z1=zeros(sz,'like',X1); 
            Z1(:,:,1:end-4,:)=X1(:,:,:,:);

            HphiY=X1(:,:,1,:)+1i*X1(:,:,2,:); 
            EphiY=X1(:,:,3,:)+1i*X1(:,:,4,:); 

            epsY=X1(:,:,5,:)+1i*X1(:,:,6,:); 
            omg0=2*pi./X1(1,1,7,:); 

            % setting differentiation matrices
            Dr=diag(-ones(sz(2)-1,1),1)/2+diag(ones(sz(2)-1,1),-1)/2;
            Dr(1)=-1; Dr(2)=1; Dr(end-1)=-1; Dr(end)=1; 
            Dr=Dr/(layer.r2(1,2)-layer.r2(1)); 
            
            Dz=diag(ones(sz(1)-1,1),1)/2-diag(ones(sz(1)-1,1),-1)/2;
            Dz(1)=-1; Dz(1,2)=1; Dz(end,end-1)=-1; Dz(end)=1; 
            Dz=Dz/(layer.z2(2)-layer.z2(1)); 
            DM=1./((layer.r2.^2).*epsY.*omg0.^2-1); 

            rHm=layer.r2.*HphiY; 
            rEm=layer.r2.*EphiY; 

            % Hrho=\pm i*(m d(Hphi*r)/dr/r^2+eps*w*d Ephi/dz)/(...) 
            Hr=-1i*(-pagemtimes(rHm,Dr)+omg0.*epsY.*(layer.r2.^2).*pagemtimes(Dz,EphiY)).*DM; % from Jake's notes
            Hz=-1i*(-pagemtimes(Dz,HphiY)-omg0.*epsY.*pagemtimes(rEm,Dr)).*layer.r2.*DM; % from Jake's notes

            % add RZ fields
            Z1(:,:,(end-3),:)=real(Hr); 
            Z1(:,:,(end-2),:)=imag(Hr); 
            Z1(:,:,(end-1),:)=real(Hz); 
            Z1(:,:,(end),:)=imag(Hz); 

        end

        
    end
end