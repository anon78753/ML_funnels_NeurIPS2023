clear 

model=load('../nets/lowResNet.MSEphi.6.11.seed=1792770071.mat');

% calculate the total number of datasets with labeled and UL data

ifl=2; 
lam0=9.6; 

cmlData=load([model.cmlPref,model.cmlMed{ifl},model.cmlSuf]);

lamArr=cmlData.lamArr; 
cmlSz=model.cmlSz;
net=model.net;

[~,i0]=min(abs(lamArr-lam0)); 
X=zeros(cmlSz); 
X(:,:,1)=real(cmlData.epsDns(:,:,i0)); 
X(:,:,2)=imag(cmlData.epsDns(:,:,i0)); 
X(:,:,3)= cmlData.lamArr(i0); 
Ftry=predict(net,X); 
HphiTry=Ftry(:,:,1)+1i*Ftry(:,:,2); 
EphiTry=Ftry(:,:,3)+1i*Ftry(:,:,4); 

HrTry=Ftry(:,:,8)+1i*Ftry(:,:,9); 


%% plotting
figure(20)
surf(cmlData.rDns,cmlData.zDns,real(cmlData.epsDns(:,:,i0)), 'EdgeColor','none')
colormap jet
view(2)
colorbar
xlabel('r,\mum')
ylabel('z,\mum')
set(gca,'FontSize',18)
box on 
daspect([1 1 1])
xlim([min(cmlData.rDns(:)),max(cmlData.rDns(:))])
ylim([min(cmlData.zDns(:)),max(cmlData.zDns(:))])
xticks([0 2 4])
set(gca,'CLim',[-1 1]*20)

figure(21)
surf(cmlData.rDns,cmlData.zDns,abs(cmlData.EphiDns(:,:,i0)), 'EdgeColor','none')
colormap hot
view(2)
colorbar
xlabel('r,\mum')
ylabel('z,\mum')
set(gca,'FontSize',18)
box on 
daspect([1 1 1])
xlim([min(cmlData.rDns(:)),max(cmlData.rDns(:))])
ylim([min(cmlData.zDns(:)),max(cmlData.zDns(:))])
xticks([0 2 4])
set(gca,'CLim',[0 1]*1.5)

figure(22)
surf(cmlData.rDns,cmlData.zDns,abs(EphiTry), 'EdgeColor','none')
colormap hot
view(2)
colorbar
xlabel('r,\mum')
ylabel('z,\mum')
set(gca,'FontSize',18)
box on 
daspect([1 1 1])
xlim([min(cmlData.rDns(:)),max(cmlData.rDns(:))])
ylim([min(cmlData.zDns(:)),max(cmlData.zDns(:))])
xticks([0 2 4])
set(gca,'CLim',[0 1]*1.5)

