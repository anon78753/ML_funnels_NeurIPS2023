classdef PGregressionRZregLayer < nnet.layer.RegressionLayer
    % Physics-guided regression layer to be used for photonic funnels work
    properties (Access = public)
        r2; %coordinate arrays
        z2; 
        iter0; % iteration when switchover from MSE to PG loss occurs
        diter; % number of iterations over which switchoover occurs

        pgWt; % PG weight at the end of the training
        rmWtMin; % MSE weight at the beginning of the training 
        rpWt; % Hrz contritibution towards MSE weight 
        
    end 
    
    methods
        function layer = PGregressionRZregLayer(name,r2,z2,iter0,diter,rmWtMin,pgWt,rpWt)
            % default constructor
			
            % Set layer name.
            layer.Name = name;

            % Set layer description.
            layer.Description = 'PGML loss layer';

            %config parameters
            layer.r2=r2; 
            layer.z2=z2; 
            layer.iter0=iter0; layer.diter=diter; 
            layer.rmWtMin=rmWtMin; layer.pgWt=pgWt; 
            layer.rpWt=rpWt; 
        end
        
        function loss = forwardLoss(layer, Y, T)
            % loss = forwardLoss(layer, Y, T) returns the loss between
            % the predictions Y and the training targets T.
            % both T and Y have dimensions of rSize x zSize x 11 x Nminibatch

            persistent iter; % keeps track of training iteration 
            % (note: loss function is called twice per iteration due to auto diff)
            if isempty(iter)
                iter=0; 
            end 
            iter=iter+1; 

            sz=size(Y);
            Y=real(Y); T=real(T); % patches Matlab 2022 issue with complex numbers within autodiff


            % initialize phi fields and wavelength
            HphiY=Y(:,:,1,:)+1i*Y(:,:,2,:); 
            HphiT=T(:,:,1,:)+1i*T(:,:,2,:); 
            EphiY=Y(:,:,3,:)+1i*Y(:,:,4,:); 
            EphiT=T(:,:,3,:)+1i*T(:,:,4,:); 

            epsY=Y(:,:,5,:)+1i*Y(:,:,6,:); 
            omg0=2*pi./Y(1,1,7,:); 

            % mark labeled data
            lbls=T(2,1,7,:); 
            ilb=(lbls~=-1); 

            % prepare dynamic weights 
            [smUp,smDn]=smoothStep(iter/2,layer.iter0,layer.diter); 
            
            % initialize r/z fields
            HrY=Y(:,:,8,:)+1i*Y(:,:,9,:); 
            HrT=T(:,:,8,:)+1i*T(:,:,9,:); 
            HzY=Y(:,:,10,:)+1i*Y(:,:,11,:); 
            HzT=T(:,:,10,:)+1i*T(:,:,11,:); 

            % scaling matrices 
            DM=1./((layer.r2.^2).*epsY.*omg0.^2-1); 
            DMreg=1e-1./DM./((layer.r2.^2).*omg0.^2+0.1); %regularization matrix

            radStep=(1+10./(1+10*exp(2*(layer.r2-3))))/2; %radial weight function

            HrDif=layer.rpWt*(HrY-HrT).*DMreg; 
            HzDif=layer.rpWt*(HzY-HzT).*DMreg; 

            ErrY=sum((abs(HphiY-HphiT).^2+abs(HrDif).^2+abs(HzDif).^2+...
                abs(EphiY-EphiT).^2).*radStep,[1,2])/sz(1)/sz(2); %
            ErrY=(layer.rmWtMin+(1-layer.rmWtMin)*smDn)*sum(ErrY.*ilb)/sum(ilb); % MSE loss calculated
            % note: MSE loss is averaged over labeled data

            
            % setting differentiation matrices
            Dr=diag(-ones(sz(2)-1,1),1)/2+diag(ones(sz(2)-1,1),-1)/2;
            Dr(1)=-1; Dr(2)=1; Dr(end-1)=-1; Dr(end)=1; 
            Dr=Dr/(layer.r2(1,2)-layer.r2(1)); 
            
            Dz=diag(ones(sz(1)-1,1),1)/2-diag(ones(sz(1)-1,1),-1)/2;
            Dz(1)=-1; Dz(1,2)=1; Dz(end,end-1)=-1; Dz(end)=1; 
            Dz=Dz/(layer.z2(2)-layer.z2(1)); 


            % calculating physics loss 
            HrYreg=HrY.*DMreg; 
            HzYreg=HzY.*DMreg; 
            EphiYreg=EphiY.*DMreg; 

            ErrPhReg=pagemtimes((HzYreg.*DMreg),Dr)-pagemtimes(Dz,(HrYreg.*DMreg))...
                +1i*omg0.*epsY.*EphiYreg.*DMreg...
                -2*(HzYreg.*pagemtimes(DMreg,Dr)-HrYreg.*pagemtimes(Dz,DMreg));

            ErrPh=sum(abs(ErrPhReg),[1,2])./max(abs(HphiY),[],[1,2])/sz(1)/sz(2); %physics loss calculated 

            %averaging PH loss over minibatch
            if length(sz)>3
                ErrPh=layer.pgWt*smUp*sum(ErrPh)/sz(4); 
            else 
                ErrPh=layer.pgWt*smUp*sum(ErrPh);
            end 

            loss=ErrY+ErrPh; % total loss calculated
        end
        
        
    end
end