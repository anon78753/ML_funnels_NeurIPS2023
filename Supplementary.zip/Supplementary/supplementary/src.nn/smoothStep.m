function [u,d] = smoothStep(x,x0,delta)
%SMOOTHSTEP Summary of this function goes here
%   Detailed explanation goes here

u=1./(1+exp(-(x-x0)/delta)); 
d=1./(1+exp((x-x0)/delta));
end

