This supplementary folder contains 
1) 5 low-resolution datasets under /cmlData/
2) 3 trained example networks under /nets/
3) Scripts and functions to train and evaluate the networks uner /src.nn/

The low-resolution datasets are all for the same geometry but with plasmonic materials having different plasma wavelengths.
The 3 trained networks were trained on the same data, except that the physics guided network uses unlabeled (no fields) data for additional training.

trainMLnetworkLowRes.m can be run to train additional networks with various loss parameters/training sets. 

metricAnalysis.m, metricAnalysisAvg.m, and intensityAnalysis.m can be used to analyze the performance of the networks and generate figures like those in the paper. 